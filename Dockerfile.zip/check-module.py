import json, pytz, psycopg2, subprocess
from datetime import datetime, date, timedelta

def _query(_sql):
  con = psycopg2.connect(
	database="",
	user="",
	password="",
	host="",
	port= '5432'
  )
  cursor_obj = con.cursor()
  cursor_obj.execute("SELECT * FROM bike_details")
  result = cursor_obj.fetchall()
  return result
  
_res = _query("select modulename from installed_modules where date_added_to_airflow is null")
if _res is not None and len(_res) > 0:
  result = subprocess.run(['bash', './cluster-setup.sh', '<username>', '<password>', '<tenant-id>', '<cluster name>', 'k8s-namespace'], capture_output = True, text = True)

print(result.stdout)
