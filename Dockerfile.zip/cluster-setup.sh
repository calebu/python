#!/bin/bash
az login --service-principal -u $1 -p $2 --tenant $3 
az aks create -g sg-rg -n $4 --enable-managed-identity --node-count 1 --enable-addons monitoring --enable-msi-auth-for-monitoring  --generate-ssh-keys
az aks get-credentials --name $4 --resource-group "sg-rg" --admin
./kubectl get ns
./kubectl create ns $5
#echo $4

