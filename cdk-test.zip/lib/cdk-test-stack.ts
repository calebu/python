import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as sqs from 'aws-cdk-lib/aws-sqs';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as codecommit from 'aws-cdk-lib/aws-codecommit';
import * as codebuild from 'aws-cdk-lib/aws-codebuild';
import * as codepipeline from 'aws-cdk-lib/aws-codepipeline';
import * as codepipeline_actions from 'aws-cdk-lib/aws-codepipeline-actions';
import {
  CodeBuildAction,
  GitHubSourceAction
} from "aws-cdk-lib/aws-codepipeline-actions";

export class CdkTestStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Define the github sources

    const build_project = new codebuild.Project(this, 'MyProject', {
      buildSpec: codebuild.BuildSpec.fromObject({
        version: '0.2',
        phases: {
          build: {
            commands: [
              'curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"',
              'curl -fsSL -o get_helm.sh https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 && chmod 700 get_helm.sh && ./get_helm.sh && helm',
            ],
          },
        },
      }),
    });

    const sourceOutput = new codepipeline.Artifact();
    const sourceOutput1 = new codepipeline.Artifact();

    const source_action = new codepipeline_actions.GitHubSourceAction({
      actionName: "First_Source",
      // outputs to the sourceCode artifact
      output: sourceOutput,
      owner: "calebu",
      repo: "python",
      branch: "feature",
      oauthToken: cdk.SecretValue.secretsManager('github_PAT2')
    })


    const source_action2 = new codepipeline_actions.GitHubSourceAction({
      actionName: "Second_Source",
      // outputs to the sourceCode artifact
      output: sourceOutput1,
      owner: "calebu",
      repo: "adf_cicd",
      branch: "This-is-ELDO-2-branch",
      oauthToken: cdk.SecretValue.secretsManager('github_PAT2')
    })


    new codepipeline.Pipeline(this, 'Pipeline', {
      stages: [
        {
          stageName: 'Source',
          actions: [source_action, source_action2],
        },
        {
          stageName: 'Build',
          actions: [
            new codepipeline_actions.CodeBuildAction({
              actionName: 'codePipelineBuildAction',
              project: build_project,
              input: sourceOutput1,
              runOrder: 2,
            }),


          ],
        }
      ],
    });

  }
}
